import spock.lang.*


class SkeletonTest extends Specification {

	def "A Hello World Example"(){
		given: "Two parts of a sentence"
			def word1 = "Hello "
			def word2 = "World!"

		when: "Those are concatenated"
			def greeting=word1+word2

		then: "We should get Hello World"
			greeting == "Hello World!"
	}

}
